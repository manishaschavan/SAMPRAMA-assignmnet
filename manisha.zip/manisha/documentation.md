# tasks to be done
1. install python 3.6
2. open command prompt and run following commands
   pip install flask
   pip install pymongo
   pip install requests
(in case it does not work use pip3 instead of pip)

3. install mongodb and create database called 'manisha'
4. run app.py file with 'python app.py' command

5. get request url is 'http://127.0.0.1:5000/api/aggregation_1min/machined_parts'
   last part of url is dynamic you replace <machined_parts> with <pressure> , <temperature>
