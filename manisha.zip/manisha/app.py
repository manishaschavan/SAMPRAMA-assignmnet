import threading
from time import sleep
from flask import Flask, jsonify
import requests
import pymongo
import statistics


app = Flask(__name__)

records = []

client = pymongo.MongoClient("mongodb://localhost:27017")
db = client.manisha
# client = pymongo.MongoClient("mongodb+srv://manisha:123@cluster0.ucdxn.mongodb.net/manisha?retryWrites=true&w=majority")
# mongo = client.manisha
crsr = db.list_collections()
for clr in crsr:
    print(clr['name'])

def requestData():
    while True:
        response = requests.get('https://myfirstiiotapp.herokuapp.com/api/metrics?api_key=gKGfPhA2Sz5Rbzmw')
        body = response.json()
        if body['status'] == 'success':
            jarray = body['data']
            # records.extend(list(jarray))
            db.data.insert_many(jarray)
            # print(len(records))
            sleep(5)
    return 'done'



@app.route('/api/aggregation_1min/<parameter>')
def index(parameter):
    resultList = []
    machineList = []
    recordList = []
    recordsCursor = db.data.find({})

    for record in recordsCursor:
        recordList.append(record)
        if not record['machine'] in machineList:
            machineList.append(record['machine'])

    print(f'list of machines is {machineList}')

    for machine in machineList:

        values = [0]
        
        for record in recordList:
            print(f'record found is {record}')

            if record['machine'] == machine:
                params = record['data']
                for param in params:
                    if param['key'] == parameter:
                        values.append(param['value'])
                        pressure = param['value']
                        print(f'pressure found for {machine} is {pressure}')

        mean = statistics.mean(values)
        resultList.append({
            'machine': machine,
            'value' : mean
        })
    
    return jsonify(resultList)





if __name__ == '__main__':
    db.data.delete_many({})
    threading.Thread(target=requestData).start()
    app.run(debug=True)